
// var myHash = new Hash({
//     customResultDisplay: {
//         'w1': {
//             message: "In Worksheet w1, you got ${correctWorksheet} correct out of ${totalWorksheet} questions.",
//             'q1': {
//                 message: "Question q1 was incorrect. The correct answer is ${correctAnswer}.",
//                 hint: "Hint for Q1: Remember..."
//             },
//             'q2': {
//                 message: "Question q2 was incorrect. The correct answer is ${correctAnswer}.",
//                 hint: "Hint for Q2: Consider..."
//             }
//             // Additional questions and hints...
//         }
//         // Additional worksheets...
//     }
// });


 // jQuery code for custom text sizes
 $(document).ready(function() {
    // Click event handler for the size buttons
    $('.changeSizeBtn').click(function() {
      // Get the selected size from the data attribute
      var newSize = $(this).data('size');

      // Map the size values to corresponding font sizes
      var sizeMap = {
        'small': '16px',
        'medium': '30px',
        'large': '50px'
      };

      // Apply the new font size to the text
      $('h1').css('font-size', sizeMap[newSize]);
      $('pre').css('font-size', sizeMap[newSize]);
    });
  });


    // jQuery code for toggling image zoom by clicking and scrolling
  $(document).ready(function() {
  var zoomLevels = {};
  var enableScrollZoom = false;
  var timer;

  $('img').on('mouseenter mouseleave', function(e) {
    e.preventDefault();

    var $currentImage = $(this);
    var currentZoomLevel = zoomLevels[$currentImage.attr('src')] || 1.5;

    if (e.type === 'mouseenter') {
      // Start timer when mouse enters
      timer = setTimeout(function() {
        enableScrollZoom = true;
        $currentImage.css({
          'transition': 'transform 0.3s ease',
          'transform': 'scale(' + currentZoomLevel + ')'
        });
      }, 1500); // Wait for 1.5 seconds before enabling zoom
    } else if (e.type === 'mouseleave') {
      // Reset timer when mouse leaves
      clearTimeout(timer);
      enableScrollZoom = false;
      $currentImage.css('transform', 'scale(1)');
    }
  });
});

// $(document).ready(function() {
//   var zoomLevels = {};
//   var enableScrollZoom = false;
//   var timer;

//   $('.image-container').on('mouseenter mouseleave', function(e) {
//     e.preventDefault();

//     var $currentContainer = $(this);
//     var $currentImage = $currentContainer.find('img');
//     var currentZoomLevel = zoomLevels[$currentImage.attr('src')] || 1.5;

//     if (e.type === 'mouseenter') {
//       // Start timer when mouse enters
//       timer = setTimeout(function() {
//         enableScrollZoom = true;
//         $currentContainer.addClass('zoomed');
//         $currentImage.css({
//           'transition': 'transform 0.3s ease',
//           'transform': 'scale(' + currentZoomLevel + ')'
//         });
//       }, 1500); // Wait for 1.5 seconds before enabling zoom
//     } else if (e.type === 'mouseleave') {
//       // Reset timer when mouse leaves
//       clearTimeout(timer);
//       enableScrollZoom = false;
//       $currentContainer.removeClass('zoomed');
//       $currentImage.css('transform', 'scale(1)');
//     }
//   });
// });







 // jQuery code for showing and hiding gallery view
 $(document).ready(function() {
    // Click event handler for the gallery button
    // $('#galleryButton').click(function() {
    //   $('header,main').css({'display':'flex','flex-wrap':'wrap', 'margin': '10px','width':'100%','font-size':'20px',
    //   'padding': '15px',
    //   'border': '1px solid #ccc',
    //   'box-sizing': 'border-box'});
    //   $('span').css({'font-size':'16px'});
    //   $('h1').css('font-size','20px');
    //   $('section').css({'height':'400px','width':'440px'});
    //   $('main .inner').css('height','320px');
    //   $('.box').css({'width':'20px','height':'20px','margin':'5px','padding':'20px'});
    //   $('.simpleGrid').css({'grid-template-columns':'1fr'});
    //   $('.customGrid').css({'grid-template-columns':'1fr'});
    //   $('.n0-i2').css({'display':'none'});

      // Click event handler for the back button
      // $('#back').click(function() {
      //   $('header, main, span, h1, section, main .inner, .box, .simpleGrid, .customGrid').removeAttr('style');
      //   $('.simpleGrid').css({'grid-template-columns':'1fr 1fr'});
      //   $('.customGrid').css({'grid-template-columns':'1fr 2fr'});
      //   $('.n0-i2').css({'display':'grid'});

        // Remove the click event handler to avoid multiple bindings
    //     $('section').off('click'); 
    //   });
    // });
  });

  // Grid view
  $(document).ready(function() {
    const listViewButton = $('.list-view-button');
    const gridViewButton = $('.grid-view-button');
    const list = $('.view');
  
    listViewButton.on('click', function() {
      list.removeClass('grid-view-filter');
      list.addClass('list-view-filter');
    });
  
    gridViewButton.on('click', function() {
      list.removeClass('list-view-filter');
      list.addClass('grid-view-filter');
    });
  });


  // scroll and trigger event

  $(document).ready(function() {
    const options = {};
  
    const observer = new IntersectionObserver(function(entries, observer) {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          console.log(entry.target);
          $(entry.target).addClass('active');
          return;
        }
        $(entry.target).removeClass('active');
      });
    }, options);
  
    $('.animate').each(function() {
      observer.observe(this);
    });
  });

    // const s1 = document.querySelectorAll('.animate');
    // const options = {};

    // const observer = new IntersectionObserver(function(entries, observer) {
    //   entries.forEach(entry => { 
    //       if (entry.isIntersecting) {
    //           console.log(entry.target);
    //           entry.target.classList.add('active');
    //           return;
    //       }
    //       entry.target.classList.remove('active');
    //   });
    // }, options);

    // s1.forEach(s1 => {
    //   observer.observe(s1);
    // });


  // window.addEventListener('scroll' ,()=>{
  //   let content = document.querySelector('#h1');
  //   let contentPosition = content.getBoundingClientRect().top;
  //   let screenPosition = window.innerHeight/6;
  //   if(contentPosition < screenPosition){
  //     content.classList.add('active')
  //   }
  //   else{
  //     content.classList.remove('active')
  //   }
   
  // })
  