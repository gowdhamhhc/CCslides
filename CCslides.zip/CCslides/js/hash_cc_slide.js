(function($) {
    $(document).ready(function() {
        var sections = $('section');
        var currentIndex = 0;
        var debounceTimeout = null;
    
        // Initialize total sections text and dots
        $('#totalSections').text(sections.length);
        for (let i = 0; i < sections.length; i++) {
            $('.dots-container').append($('<div class="dot"></div>').attr('data-section', i));
        }
        // Calculate and set the width and margin for the dots
        var dotContainerWidth = $('.dots-container').width();
        var desiredMargin = 10; // Adjust this value to control the desired space between the dots
        var totalMargin = desiredMargin * (sections.length - 1);
        var dotWidth = (dotContainerWidth - totalMargin) / sections.length;
        $('.dot').css({
            'width': dotWidth,
            'margin-right': desiredMargin
        });

        // Remove the margin from the last dot to prevent extra space on the right
        $('.dot').last().css('margin-right', 0);

        function navigate(direction) {
            // Calculate next index based on direction
            var nextIndex = currentIndex + direction;
        
            // Check if next index is out of bounds
            if (nextIndex < 0 || nextIndex >= sections.length) {
                return; // Don't do anything if the next index is out of bounds
            }
        
            // Hide current section
            var currentSection = sections.eq(currentIndex);
            currentSection.removeClass('visible');
            currentSection.find('.slide').removeClass('animate-text');
        
            // If the current section has the no-transition class, remove it
            if (currentSection.hasClass('no-transition')) {
                currentSection.removeClass('no-transition');
            }
        
            // Update current index
            currentIndex = nextIndex;
        
            // Show the next section
            var nextSection = sections.eq(currentIndex);
            nextSection.addClass('visible');
        
            // Check if the next section has the no-animate class
            if (!nextSection.hasClass('no-animate')) {
                // Delay the removal of the no-transition class and the addition of the overlay class
                setTimeout(function() {
                    nextSection.removeClass('no-transition');
                    nextSection.addClass('overlay');
        
                    // Remove the overlay effect after a delay
                    setTimeout(function() {
                        nextSection.removeClass('overlay');
                        nextSection.find('.slide').addClass('animate-text');
                    }, 500); // 500 is the duration of the transition in milliseconds
                }, 0);
            } else {
                // If the next section has the no-animate class, show it immediately without the overlay effect
                nextSection.addClass('no-transition');
        
                // Still animate the text after a delay
                setTimeout(function() {
                    nextSection.find('.slide').addClass('animate-text');
                }, 500); // 500 is the duration of the transition in milliseconds
            }
    
            // Update the section number and active dot
            updateNavigation();
        }
    
        // Debounce function
        function debounce(func, wait) {
            return function(...args) {
                clearTimeout(debounceTimeout);
                debounceTimeout = setTimeout(() => func.apply(this, args), wait);
            };
        }
    
        // Mousewheel event
        $(window).on('wheel', debounce(function(e) {
            var delta = e.originalEvent.deltaY;
            navigate(delta > 0 ? 1 : -1);
            e.preventDefault(); // Prevent the whole page from scrolling
        }, 500)); // 500 is the debounce delay in milliseconds
    
        // Keyboard event for arrow keys
        $(document).on('keydown', debounce(function(e) {
            if (e.which == 40) { // Down arrow key
                navigate(1);
            } else if (e.which == 38) { // Up arrow key
                navigate(-1);
            }
        }, 500)); // 500 is the debounce delay in milliseconds
            // Preload cursor images
        var upCursor = new Image();
        upCursor.src = 'https://hashhackcode.com/assets/up.cur';

        var downCursor = new Image();
        downCursor.src = 'https://hashhackcode.com/assets/down.cur';
        // Mousemove event to change the cursor
        $(document).mousemove(function(e) {
            var winHeight = $(window).height();
            var cursorY = e.clientY;
            if (cursorY < winHeight / 2) {
                $('body').css('cursor', 'url(' + upCursor.src + '), auto');
            } else {
                $('body').css('cursor', 'url(' + downCursor.src + '), auto');
            }
        });
    
       // Click event to navigate based on cursor position
        $(document).on('click', function(e) {
            // Ignore clicks on the navigation indicators
            if ($(e.target).closest('.navigation-indicators').length === 0) {
                navigate((e.clientY < $(window).height() / 2) ? -1 : 1);
            }
        });
    
        // Dot click navigation
        $('.dots-container').on('click', '.dot', function() {
            var index = $(this).data('section');
            navigateTo(index);
        });
    
        // Show the first section initially
        sections.eq(currentIndex).addClass('visible');
        updateNavigation(); // Call it initially
    
        // Update function to handle active dot and counter
        function updateNavigation() {
            $('.dot').removeClass('active').eq(currentIndex).addClass('active');
            $('#currentSection').val(currentIndex + 1);
        }
    
        // Change event to navigate to the section number entered by the user
        $('#currentSection').on('change', function() {
            var index = $(this).val() - 1;
            navigateTo(index);
        });
        $(document).on('mousemove', function(e) {
            if (e.clientY > $(window).height() * 0.7) {
                $('.navigation-indicators').addClass('show');
            } else {
                $('.navigation-indicators').removeClass('show');
            }

            if (e.clientY < $(window).height() * 0.2) {
                $('.top-menu').addClass('show');
            } else {
                $('.top-menu').removeClass('show');
            }
        });
        function navigateTo(index) {
            if (index < 0 || index >= sections.length) {
                return;
            }
        
            // Hide current section
            var currentSection = sections.eq(currentIndex);
            currentSection.removeClass('visible');
            currentSection.find('.slide').removeClass('animate-text');
        
            // If the current section has the no-transition class, remove it
            if (currentSection.hasClass('no-transition')) {
                currentSection.removeClass('no-transition');
            }
        
            // Update current index
            currentIndex = index;
        
            // Show the next section
            var nextSection = sections.eq(currentIndex);
            nextSection.addClass('visible');
        
            // Check if the next section has the no-animate class
            if (!nextSection.hasClass('no-animate')) {
                // Delay the removal of the no-transition class and the addition of the overlay class
                setTimeout(function() {
                    nextSection.removeClass('no-transition');
                    nextSection.addClass('overlay');
        
                    // Remove the overlay effect after a delay
                    setTimeout(function() {
                        nextSection.removeClass('overlay');
                        nextSection.find('.slide').addClass('animate-text');
                    }, 500); // 500 is the duration of the transition in milliseconds
                }, 0);
            } else {
                // If the next section has the no-animate class, show it immediately without the overlay effect
                nextSection.addClass('no-transition');
        
                // Still animate the text after a delay
                setTimeout(function() {
                    nextSection.find('.slide').addClass('animate-text');
                }, 500); // 500 is the duration of the transition in milliseconds
            }
        
            // Update the section number and active dot
            updateNavigation();
        }
    });
    })(jQuery);

  